/*
#	Le livre de Java 1er langage
#	A. Tasso
#	Chapitre 10 : Collectionner un nombre indetermine d'objets
#	Section  : Exercice 10.3 et 10.4
#	Fichier  : Cursus.java
#	Class    : Cursus
*/

import java.util.*;

 public class Cursus  {
 private ArrayList<Etudiant>  liste;
 public Cursus()   {
 	liste = new ArrayList<Etudiant>();		
 }
 public void ajouteUnEtudiant() {
	liste.add(new Etudiant());
 }
 public void afficheLesEtudiants() 	{
	int nbEtudiants = liste.size();
	if (nbEtudiants > 0) {
                  for (Etudiant e : liste) e.afficheUnEtudiant();
	}
	else System.out.println("Il n'y a pas d'etudiant dans cette liste");
 }
 
 // Pour chaque element commençant par les lettres contenues dans tmp, afficher les informations
 public void rechercheLeMajor() 	{
     Etudiant   max =liste.stream()
    .max((e1, e2) -> (e1.quelleMoyenne() - e2.quelleMoyenne()))  
    .get();
     max.afficheUnEtudiant();
    
 }
     
  public void memePrenom(String tmp) 	{
    // creation d'un flux de traitement
	liste.stream() // Pour chaque element du flux, rechercher cceux commençant par les lettres contenues ds tmp
    .filter(e -> e.quelNom().startsWith(tmp)) 
    .forEach(e -> e.afficheUnEtudiant()); // Pour chaque element commençant par les lettres contenues dans tmp, afficher les informations
  }
}